insert into roles (role_id,name) values (1,'ADMIN');

insert into users (user_id,password,username) values (1,'$2a$12$r5htAEPHde1FgovdMWFCw.1Wj6KIF2972A74d9Z3HKsqjc13BEGpK','ujjawal');

insert into users_roles (user_id,role_id) values (1,1);